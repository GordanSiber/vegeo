<!DOCTYPE html>
<html lang="en">
	<head>
		<meta http-equiv="content-type" content="text/html"/>
		<meta name="viewport" content="width=device-width,  initial-scale=1.0, maximum-scale=1.0, shrink-to-fit=no"/>
		<title>testing vegeo</title>
		<meta name="description" content="testing simplified version of vegeo"/>
		<link rel="stylesheet" href="../styles.min.css" type="text/css" media="all"/>
		<link rel="stylesheet" href="../style-menus.css" type="text/css" media="all"/>
	</head>
	<body>
		<div class="FlexWrapper">
			<div class="logcont"></div>
			<div class="HeaderWrap">
				<div class="HeaderWrap FlexHeader">
					<div class="nav-mixed-lavlam">
						<nav class="multi-level-2-nav" role="navigation">
							<ul class="vegNav gogoMoveJazz" id="main">
								<li id="vegMain" href="/" class="current"><a>about</a></li>
								<li id="vegB02" href="/black/"><a>black</a></li>
								<li id="vegB03" href="/blue/"><a>blue</a></li>
								<li id="vegB04" href="/white/"><a>white</a></li>
							</ul>
						</nav>
					</div>
				</div>
			</div>
