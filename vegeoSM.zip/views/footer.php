			<div class="FlexFooter">
				<div class="FooterFlex">
					<div class="JazzupTxt">
						<p>testing <a href=https://github.com/GordanSiber/vegeo.js><strong>vegeo</strong></a>
						</p>
					</div>
				</div>
			</div>
		</div>
		<script src="../JS/vegeSm-1.2.js"></script>
	</body>
</html>
