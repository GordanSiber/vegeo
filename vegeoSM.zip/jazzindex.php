<?php	require 'views/header.php'; ?>
			<div class='MidCont' id="content">
<?php	require 'content/jazzindex.php'; ?>
			</div>
<?php
	require 'views/footer.php';
?>
